//
//  UserModel.swift
//  JsonModelClass
//
//  Created by Hardik on 27/10/18.
//  Copyright © 2018 Hardik. All rights reserved.
//

import Foundation
import SwiftyJSON
/*
 {
 "userId": 1,
 "id": 1,
 "title": "delectus aut autem",
 "completed": false
 }
 */
struct User {
    var userId : Int
    var id : Int
    var title : String
    var completed : Bool

    init(dic : [String : Any])
    {
        self.userId = dic["userId"] as? Int ?? 0
        self.id = dic["id"] as? Int ?? 0
        self.title = dic["title"] as? String ?? ""
        self.completed = dic["completed"] as? Bool ?? false
    }
}


class UserInfo
{
    var userId : Int
    var id : Int
    var title : String
    var completed : Bool
    
    init(json : JSON)
    {
        userId = json["userId"].intValue
        id = json["id"].intValue
        title = json["title"].stringValue
        completed = json["completed"].boolValue
    }
}
