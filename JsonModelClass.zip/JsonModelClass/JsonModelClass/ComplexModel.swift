//
//  ComplexModel.swift
//  JsonModelClass
//
//  Created by Hardik on 27/10/18.
//  Copyright © 2018 Hardik. All rights reserved.
//

import Foundation
import SwiftyJSON

class ResponseClass
{
    var page : Int
    var per_page : Int
    var total : Int
    var total_pages : Int
    var data : [[String:Any]]
    
    init(json : [String : Any]) {
        page = (json["page"]! as AnyObject).intValue
        per_page = (json["per_page"]! as AnyObject).intValue
        total = (json["total"]! as AnyObject).intValue
        total_pages = (json["total_pages"]! as AnyObject).intValue
        data = (json["data"]! as AnyObject) as! [[String : Any]]
    }
        
}
