//  ComplexWSResponse.swift
//  JsonModelClass
//  Created by Hardik on 27/10/18.
//  Copyright © 2018 Hardik. All rights reserved.

import UIKit
import Alamofire
import Alamofire_SwiftyJSON
import SwiftyJSON
class ComplexWSResponse: UIViewController {
 var model = [ResponseClass]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        callWS()
        
        
    
        
        
        callWS1()
    }
    
    func callWS()
    {
        Alamofire.request("https://reqres.in/api/users?page=2", method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseSwiftyJSON { (response) in
            if let data = response.result.value
            {
                // use by structure
                //                let  ArytblList = data.arrayObject as! [[String : Any]]
                //                for dic in ArytblList
                //                {
                //                    self.model.append(User(dic: dic))
                //                }
                //                print(model[0].userId)
                
                // use by class
                let  ArytblList = data.dictionaryObject
                self.model.append(ResponseClass(json: ArytblList!))
//                print(self.model[0].data)
                print((self.model[0].data)[0]["first_name"] as Any)
            }
        }
    }
    
    func callWS1() {
        Alamofire.request("http://jsonplaceholder.typicode.com/users/1", method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseSwiftyJSON { (response) in
            
            if let data = response.result.value
            {
                print(data.dictionaryObject!["website"]!)
            }
        }
    }
}
