//
//  ViewController.swift
//  JsonModelClass
//
//  Created by Hardik on 27/10/18.
//  Copyright © 2018 Hardik. All rights reserved.
//

import UIKit
import Alamofire
import Alamofire_SwiftyJSON
import SwiftyJSON
class ViewController: UIViewController {
    //    var model = [User]()
    var model = [UserInfo]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        callWS()
        
        
        
    }
    
    func callWS()
    {
        Alamofire.request("https://jsonplaceholder.typicode.com/todos", method: .get, parameters: nil, encoding: JSONEncoding.default, headers: nil).responseSwiftyJSON { (response) in
            if let data = response.result.value
            {
                // use by structure
                //                let  ArytblList = data.arrayObject as! [[String : Any]]
                //                for dic in ArytblList
                //                {
                //                    self.model.append(User(dic: dic))
                //                }
                //                print(model[0].userId)
                
                // use by class
                let  ArytblList = data.array
                for dic in ArytblList!
                {
                    self.model.append(UserInfo(json: dic))
                }
                print(self.model[0].title)
            }
        }
    }
    
}

